import cv2
import mediapipe as mp
import threading
#
import serial
import sys
import threading, queue
import math
import time

cls = lambda: print('\n'*10)

global connected,baud,serial_port,screen,qr,qw, Nums


mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
mp_hands = mp.solutions.hands
drawingModule = mp.solutions.drawing_utils

# For webcam input:
cap = cv2.VideoCapture(0)
pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5);
hands = mp_hands.Hands(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5);

frameWidth = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
frameHeight = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

def PyVisual():
    global connected,baud,serial_port,screen,qr,qw, Narr
    while cap.isOpened():
        success, image = cap.read()
        if not success:
          print("Ignoring empty camera frame.")
          # If loading a video, use 'break' instead of 'continue'.
          continue
        if qr.empty() == False:
            item = qr.get(timeout=0.1)
            strt = ""
            for i in item:
                strt = strt + i.decode("utf-8")
            print("Read\t" + strt)
            qr.queue.clear()
            qr.task_done()

        # Flip the image horizontally for a later selfie-view display, and convert
        # the BGR image to RGB.
        image = cv2.cvtColor(cv2.flip(image, 1), cv2.COLOR_BGR2RGB)
        # To improve performance, optionally mark the image as not writeable to
        # pass by reference.
        image.flags.writeable = False
        resultsP = pose.process(image)
        resultsH = hands.process(image)
        # Draw the pose annotation on the image.
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
               
        if resultsH.multi_hand_landmarks:
          #print('Handedness:', resultsH.multi_handedness)
          for idx,hand_landmarks in enumerate(resultsH.multi_hand_landmarks):
            if resultsH.multi_handedness[idx].classification[0].label == 'Right':
                mp_drawing.draw_landmarks(
                    image, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                x1=0;x2=0;x3=0;y1=0;y2=0;y3=0;z1=0;z2=0;z3=0;
                for point in mp_hands.HandLandmark:
                    normalizedLandmark = hand_landmarks.landmark[point]
                    if point == mp_hands.HandLandmark.WRIST:
                        x1 = normalizedLandmark.x; y1 = normalizedLandmark.y; z1 = normalizedLandmark.z;
                        pixelCoordinatesLandmark = drawingModule._normalized_to_pixel_coordinates(normalizedLandmark.x, normalizedLandmark.y, frameWidth, frameHeight)
                        cv2.circle(image, pixelCoordinatesLandmark, 10, (64, 64, 0), -1)
                    elif point == mp_hands.HandLandmark.MIDDLE_FINGER_TIP:
                        x2 = normalizedLandmark.x; y2 = normalizedLandmark.y;
                        pixelCoordinatesLandmark = drawingModule._normalized_to_pixel_coordinates(normalizedLandmark.x, normalizedLandmark.y, frameWidth, frameHeight)
                        cv2.circle(image, pixelCoordinatesLandmark, 10, (255, 255, 0), -1)
                    elif point == mp_hands.HandLandmark.THUMB_TIP:
                        x3 = normalizedLandmark.x; y3 = normalizedLandmark.y; z3 = normalizedLandmark.z;
                        pixelCoordinatesLandmark = drawingModule._normalized_to_pixel_coordinates(normalizedLandmark.x, normalizedLandmark.y, frameWidth, frameHeight)
                        cv2.circle(image, pixelCoordinatesLandmark, 10, (128, 128, 0), -1)
                    dist = math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1))
                    dist = int(-int(dist*400)*3.2 + 400)
                s1 = math.atan2(z1 - z3, y1 - y3); s2 = math.atan2(z1 - z3, x1 - x3)
                as1 = int(s1*180/math.pi); as2 = int(s2*180/math.pi);
                text= ('B1: '+str(as1) +'  B2: '+str(as2) + ' d:' + str(dist));
                cv2.rectangle(image, (0,30), (600,30), (0,0,0), 20)
                cv2.putText(image, text, (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 2, cv2.LINE_AA)
                Narr[1] = dist; Narr[0] = (as1+as2)+60;
                qw.put(Narr)
                
                    
        cv2.imshow('MediaPipe Pose', image)
        
        if cv2.waitKey(5) & 0xFF == 27:
          break
    cap.release()

global rlist
rlist = []

import time

def read_from_port(ser):
    global connected,baud,serial_port,screen,qr,qw, Nums, rlist
    while not connected:
        #serin = ser.read()
        connected = True
        while True:
            if serial_port.inWaiting():
                reading = serial_port.read()
                if reading == b'\n' or reading == b'\r':
                    qr.put(rlist.copy())
                    rlist.clear()
                    serial_port.flushInput()
                else:
                    rlist.append(reading)
            if qw.empty() == False:
                item = qw.get(timeout=0.1)
                strg = ','.join(map(str, item))
                strg = str.encode(strg)
                print('Write');print(strg)
                serial_port.write(strg)
                
                while not qw.empty():
                    qw.get()
                                

if __name__ == '__main__':
    global connected,baud,serial_port,screen,myFont,q, Narr
    Narr = [0,0,0,0,0]
    qr = queue.Queue()
    qw = queue.Queue()
    connected = False
    serial_port = ();serial_port_en = 0
    try:
        serial_port = serial.Serial('/dev/ttyUSB0', baudrate = 38400)#, bytesize=8, parity='N', stopbits=1, timeout=0.01, xonxoff=0, rtscts=0)
        serial_port_en = 1
    except:
        try:
            serial_port = serial.Serial('/dev/ttyACM0', baudrate = 38400, bytesize=serial.EIGHTBITS,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,timeout=1,xonxoff=0,rtscts=0)#, bytesize=8, parity='N', stopbits=1, timeout=0.01, xonxoff=0, rtscts=0)
            serial_port_en = 1
        except:
            print ("No port!")
    if serial_port_en:
        serial_port.setDTR(False)
        time.sleep(1)
        serial_port.flushInput()
        #serial_port.setDTR(True)
        serial_port.flush()
        print(serial_port.name)
        thread = threading.Thread(target=read_from_port, args=(serial_port,))
        thread.start()
    
    thread = threading.Thread(target=PyVisual, args=())
    thread.start()

