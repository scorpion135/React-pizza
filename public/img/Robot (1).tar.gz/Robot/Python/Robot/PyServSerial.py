# -*- coding: utf-8 -*-
# Импортируем все необходимые библиотеки:
import serial
import numpy as np
import os
import time
import threading
import math 
from multiprocessing import Queue
from threading import Thread
import sys
from io import StringIO
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *


# Объявляем все глобальные переменные
global xrot         # Величина вращения по оси x
global yrot         # Величина вращения по оси y
global ambient      # рассеянное освещение
global greencolor   # Цвет елочных иголок
global treecolor    # Цвет елочного стебля
global lightpos     # Положение источника освещения
global inputArr
global disp
disp = 0
inputArr = []
global inputArrScreen 
inputArrScreen = []

# Процедура инициализации
def init():
    global xrot         # Величина вращения по оси x
    global yrot         # Величина вращения по оси y
    global ambient      # Рассеянное освещение
    global greencolor   # Цвет елочных иголок
    global treecolor    # Цвет елочного ствола
    global lightpos     # Положение источника освещения

    xrot = 0.0                          # Величина вращения по оси x = 0
    yrot = 0.0                          # Величина вращения по оси y = 0
    ambient = (1.0, 1.0, 1.0, 1)        # Первые три числа цвет в формате RGB, а последнее - яркость
    greencolor = (0.2, 0.8, 0.0, 0.8)   # Зеленый цвет для иголок
    treecolor = (0.9, 0.6, 0.3, 0.8)    # Коричневый цвет для ствола
    lightpos = (1.0, 1.0, 1.0)          # Положение источника освещения по осям xyz

    glClearColor(0.5, 0.5, 0.5, 1.0)                # Серый цвет для первоначальной закраски
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0)                # Определяем границы рисования по горизонтали и вертикали
    glRotatef(-90, 1.0, 0.0, 0.0)                   # Сместимся по оси Х на 90 градусов
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient) # Определяем текущую модель освещения
    glEnable(GL_LIGHTING)                           # Включаем освещение
    glEnable(GL_LIGHT0)                             # Включаем один источник света
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos)     # Определяем положение источника света


# Процедура обработки специальных клавиш
def specialkeys(key, x, y):
    global xrot
    global yrot
    # Обработчики для клавиш со стрелками
    if key == GLUT_KEY_UP:      # Клавиша вверх
        xrot -= 2.0             # Уменьшаем угол вращения по оси Х
    if key == GLUT_KEY_DOWN:    # Клавиша вниз
        xrot += 2.0             # Увеличиваем угол вращения по оси Х
    if key == GLUT_KEY_LEFT:    # Клавиша влево
        yrot -= 2.0             # Уменьшаем угол вращения по оси Y
    if key == GLUT_KEY_RIGHT:   # Клавиша вправо
        yrot += 2.0             # Увеличиваем угол вращения по оси Y

    glutPostRedisplay()         # Вызываем процедуру перерисовки


# Процедура перерисовки
def draw():
    global xrot
    global yrot
    global zrot
    global lightpos
    global greencolor
    global treecolor

    glClear(GL_COLOR_BUFFER_BIT)                                # Очищаем экран и заливаем серым цветом
    glPushMatrix()                                              # Сохраняем текущее положение "камеры"
    glRotatef(xrot, 1.0, 0.0, 0.0)                              # Вращаем по оси X на величину xrot
    glRotatef(yrot, 0.0, 1.0, 0.0)                              # Вращаем по оси Y на величину yrot
    glRotatef(zrot, 0.0, 0.0, 1.0)                              # Вращаем по оси Z на величину yrot
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos)                 # Источник света вращаем вместе с елкой

    # Рисуем ствол елки
    # Устанавливаем материал: рисовать с 2 сторон, рассеянное освещение, коричневый цвет
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, treecolor)
    glTranslatef(0.0, 0.0, -0.7)                                # Сдвинемся по оси Z на -0.7
    # Рисуем цилиндр с радиусом 0.1, высотой 0.2
    # Последние два числа определяют количество полигонов
    glutSolidCylinder(0.1, 0.2, 20, 20)
    # Рисуем ветки елки
    # Устанавливаем материал: рисовать с 2 сторон, рассеянное освещение, зеленый цвет
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, greencolor)
    glTranslatef(0.0, 0.0, 0.2)                                 # Сдвинемся по оси Z на 0.2
    # Рисуем нижние ветки (конус) с радиусом 0.5, высотой 0.5
    # Последние два числа определяют количество полигонов
    glutSolidCone(0.5, 0.5, 20, 20)
    glTranslatef(0.0, 0.0, 0.3)                                 # Сдвинемся по оси Z на -0.3
    glutSolidCone(0.4, 0.4, 20, 20)                             # Конус с радиусом 0.4, высотой 0.4
    glTranslatef(0.0, 0.0, 0.3)                                 # Сдвинемся по оси Z на -0.3
    glutSolidCone(0.3, 0.3, 20, 20)                             # Конус с радиусом 0.3, высотой 0.3

    glPopMatrix()                                               # Возвращаем сохраненное положение "камеры"
    glutSwapBuffers()                                           # Выводим все нарисованное в памяти на экран
    glutPostRedisplay()         # Вызываем процедуру перерисовки



class SerialIO(Thread):
    DATALENGTH = 100
    def __init__(self, out_queue_main, out_queue_server):
        Thread.__init__(self)
        self.out_queue_main = out_queue_main
        self.out_queue_server = out_queue_server
        self.ser = serial.Serial('COM12',9600) #
        self.SensorAngleWX = 0
        self.SensorAngleWY = 0
        self.SensorAngleWZ = 0
        self.SensorAccelX = 0
        self.SensorAccelY = 0
        self.SensorAccelZ = 0

    def __del__(self):
        self.ser.close()
    def run(self):
        while True:
            XCurr = 0
            reading = self.ser.readline(SerialIO.DATALENGTH) #чтение данных с COM-порта от акселерометра и гироскопа
            while self.ser.inWaiting():
                self.ser.read()              #чтение строки
            seq = []
            numer = ""
            for c in reading:
                ch = chr(c)                 #преобразование в символ
                numer += ch
                numer.rstrip("\n\r")
                if (ch == '\t'):
                    seq.append(int(numer))          #преобразование в число
                    numer = ""
            print (seq)
            global xrot                         #вращение по выбранным осям
            global yrot
            global zrot
            global disp
            xrot = math.atan2(seq[0],seq[1])*180/3.14
            yrot = math.atan2(seq[1],seq[2])*180/3.14
            zrot = math.atan2(seq[2],seq[0])*180/3.14
            if (disp):
                glutPostRedisplay()

            
    
class MainCycle(Thread):
    def __init__(self, out_queue_main):
        Thread.__init__(self)
        self.out_queue_main = out_queue_main
    def __del__(self):
        pass
    def run(self):
        while True:
            global inputArrScreen
            if self.out_queue_main.qsize() == 0:
                continue
            inputArrScreen = self.out_queue_main.get()
            while self.out_queue_main.qsize():
                self.out_queue_main.get()
            print(inputArrScreen)

if __name__ == '__main__':
    
    out_queue_main = Queue()
    out_queue_server = Queue()

    t = SerialIO(out_queue_main, out_queue_server)
    t.daemon = True
    t.start()
    #t.join(20)
    t = MainCycle(out_queue_main)
    t.daemon = True
    t.start()
    # Использовать двойную буферизацию и цвета в формате RGB (Красный, Зеленый, Синий)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
    # Указываем начальный размер окна (ширина, высота)
    glutInitWindowSize(300, 300)
    # Указываем начальное положение окна относительно левого верхнего угла экрана
    glutInitWindowPosition(50, 50)
    # Инициализация OpenGl
    glutInit(sys.argv)
    # Создаем окно с заголовком "Happy New Year!"
    glutCreateWindow(b"Proekt MEMS Stend accelerometer")
    # Определяем процедуру, отвечающую за перерисовку
    glutDisplayFunc(draw)
    # Определяем процедуру, отвечающую за обработку клавиш
    glutSpecialFunc(specialkeys)
    # Вызываем нашу функцию инициализации
    init()
    global disp
    disp = 1
    # Запускаем основной цикл
    glutMainLoop()



