import cv2
import mediapipe as mp
import threading
import numpy as np
#
import serial
import sys
import threading, queue
import math
import time

cls = lambda: print('\n'*10)

global connected,baud,serial_port,screen,qr,qw, Nums


mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
mp_hands = mp.solutions.hands
drawingModule = mp.solutions.drawing_utils

# For webcam input:
cap = cv2.VideoCapture(0)
pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5);
hands = mp_hands.Hands(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5);

frameWidth = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
frameHeight = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

def PyVisual():
    global connected,baud,serial_port,screen,qr,qw, Narr
    while cap.isOpened():
        success, image = cap.read()
        if not success:
          print("Ignoring empty camera frame.")
          # If loading a video, use 'break' instead of 'continue'.
          continue
        if qr.empty() == False:
            item = qr.get(timeout=0.1)
            strt = ""
            for i in item:
                strt = strt + i.decode("utf-8")
            print("Read\t" + strt)
            qr.queue.clear()
            qr.task_done()

       
        gray = cap.set(cv2.CAP_PROP_MODE, cv2.IMREAD_GRAYSCALE)#cv2.cvtColor(cv2.UMat(img), cv2.COLOR_BGR2GRAY) #convert roi into gray

        Blur=cv2.GaussianBlur(gray,(5,5),1) #apply blur to roi    
        Canny=cv2.Canny(np.uint8(Blur),10,50) #apply canny to roi


        
        contours =cv2.findContours(Canny,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)[0]

        #Loop through my contours to find rectangles and put them in a list, so i can view them individually later.
        cntrRect = []
        print (len(contours))
        for i in contours:
             epsilon = 0.05*cv2.arcLength(i,True)
             approx = cv2.approxPolyDP(i,epsilon,True)
             if len(approx) == 4:
                 cv2.drawContours(image,cntrRect,-1,(0,255,0),2)
                 #cv2.imshow('Roi Rect ONLY',image)
                 cntrRect.append(approx)              
                
        cv2.imshow('MediaPipe Pose', Blur)
        
        if cv2.waitKey(5) & 0xFF == 27:
          break
    cap.release()

global rlist
rlist = []

import time

def read_from_port(ser):
    global connected,baud,serial_port,screen,qr,qw, Nums, rlist
    while not connected:
        #serin = ser.read()
        connected = True
        while True:
            if serial_port.inWaiting():
                reading = serial_port.read()
                if reading == b'\n' or reading == b'\r':
                    qr.put(rlist.copy())
                    rlist.clear()
                    serial_port.flushInput()
                else:
                    rlist.append(reading)
            if qw.empty() == False:
                item = qw.get(timeout=0.1)
                strg = ','.join(map(str, item))
                strg = str.encode(strg)
                print('Write');print(strg)
                serial_port.write(strg)
                
                while not qw.empty():
                    qw.get()
                                

if __name__ == '__main__':
    global connected,baud,serial_port,screen,myFont,q, Narr
    Narr = [0,0,0,0,0]
    qr = queue.Queue()
    qw = queue.Queue()
    connected = False
    serial_port = ();serial_port_en = 0
    try:
        serial_port = serial.Serial('/dev/ttyUSB0', baudrate = 38400)#, bytesize=8, parity='N', stopbits=1, timeout=0.01, xonxoff=0, rtscts=0)
        serial_port_en = 1
    except:
        try:
            serial_port = serial.Serial('/dev/ttyACM0', baudrate = 38400, bytesize=serial.EIGHTBITS,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,timeout=1,xonxoff=0,rtscts=0)#, bytesize=8, parity='N', stopbits=1, timeout=0.01, xonxoff=0, rtscts=0)
            serial_port_en = 1
        except:
            print ("No port!")
    if serial_port_en:
        serial_port.setDTR(False)
        time.sleep(1)
        serial_port.flushInput()
        #serial_port.setDTR(True)
        serial_port.flush()
        print(serial_port.name)
        thread = threading.Thread(target=read_from_port, args=(serial_port,))
        thread.start()
    
    thread = threading.Thread(target=PyVisual, args=())
    thread.start()

