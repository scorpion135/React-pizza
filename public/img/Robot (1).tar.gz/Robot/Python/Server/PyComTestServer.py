import serial
import numpy as np
import os
import time
import threading 
from multiprocessing import Queue
from threading import Thread
import socket
import sys
import socketserver

def twos_comp(val, bits):
    """compute the 2's complement of int value val"""
    if (val & (1 << (bits - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
        val = val - (1 << bits)        # compute negative value
    return val

strings = {
"0x0 0x0 0x0 0x0":["Start",0,3],
"0x0 0x0 0x0 0x1":["Ping",0,3],
"0x1a 0xa5 0xbd 0x0":["44",1,1],
"0xf0 0x6c 0xbe 0x0":["42",1,1],
"0x1d 0xa5 0xbd 0x0":["40",2,1],
"0x78 0x4f 0xbe 0x0":["38",2,1],
"0x7a 0x4f 0xbe 0x0":["36",3,1],
"0x8b 0x6e 0xbe 0x0":["34",3,1],
"0x1c 0xa5 0xbd 0x0":["32",4,1],
"0xf4 0x6c 0xbe 0x0":["30",4,1],
"0x1b 0xa5 0xbd 0x0":["28",5,1],
"0x66 0x2c 0xbe 0x0":["26",5,1],
"0x1e 0xa5 0xbd 0x0":["24",6,1],
"0xee 0x6c 0xbe 0x0":["20",6,1],
"0x13 0x3d 0xbe 0x0":["22",7,1],
"0x88 0x6e 0xbe 0x0":["14",7,1],
"0xe1 0x2d 0xbe 0x0":["18",7,1],
"0xf1 0x6c 0xbe 0x0":["16",8,1],
"0x1f 0xa5 0xbd 0x0":["12",8,1],
"0x20 0xa5 0xbd 0x0":["10",9,1],
"0xef 0x6c 0xbe 0x0":["8",9,1],
"0x77 0x4f 0xbe 0x0":["6",10,1],
"0x12 0x3d 0xbe 0x0":["2",10,1],
"0xce 0xa7 0xbd 0x0":["4",11,1],
"0x7e 0x95 0xbd 0x0":["58",11,2],
"0x8c 0x6e 0xbe 0x0":["62",12,2],
"0x79 0x4f 0xbe 0x0":["54",12,2],
"0xf3 0x6c 0xbe 0x0":["56",13,2],
"0x77 0x95 0xbd 0x0":["1Л",0,1],
"0xbc 0x8f 0xbd 0x0":["1П",0,1],
"0x78 0x95 0xbd 0x0":["2Л",0,2],
"0x7a 0x18 0x87 0x0":["1П",0,1],
"0x10 0x3d 0xbe 0x0":["3Л",0,3],
"0x76 0x95 0xbd 0x0":["3П",0,3],
"0x4a 0x8b 0x86 0x0":["2П",0,2],
"0x72 0xb1 0x8b 0x0":["4П",0,4],
"0x87 0x6e 0xbe 0x0":["5П",0,5],
"0x8 0x9 0xa 0xb":["z",0,0]
}

 
class ThreadedTCPHandler(socketserver.StreamRequestHandler):
    def __init__(self, request, client_address, server):
        self.out_queue_server = server.out_queue_server
        socketserver.StreamRequestHandler.__init__(self, request, client_address, server)
    def handle(self):
        data = str(self.request.recv(1024), 'ascii')
        self.request.send("200")
        print (data)
        cur_thread = threading.current_thread()
        inputArr = self.out_queue_server.get()
        while self.out_queue_server.qsize():
            self.out_queue_server.get()
        Tonly, Vagon, Mesto, XCurr, Skorost, door, Schitivatel, Temperatura, Voltage, Zar, LocDB, RetDB, TelDB = inputArr
        self.out_queue_server.task_done()
        

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True,
                 queue=None):
        self.out_queue_server = queue
        socketserver.TCPServer.__init__(self, server_address, RequestHandlerClass,
                           bind_and_activate=bind_and_activate)

class SerialIO(Thread):
    DATALENGTH = (4+1+2+1+2+1+1+1+1)
    def __init__(self, out_queue_main, out_queue_server):
        Thread.__init__(self)
        self.out_queue_main = out_queue_main
        self.out_queue_server = out_queue_server
        self.ser = serial.Serial('COM3',9600) #timeout = 0.2
        self.DverSost_1 = 0
        self.XCurr_1 = 0
        self.Seconds_1 = 0
        self.StopCtr = 0
    def __del__(self):
        self.ser = serial.close()
    def run(self):
        DverSost = 0
        XCurr = 0
        RXTXLENGTH = (DATALENGTH + 9)
        reading = ser.readline(RXTXLENGTH)
        Str = ' '.join([hex(reading[i]) for i in range(8,12)])
        temper = (reading[14]*256 + reading[13])/16.0
        door = "Закрыта"
        DverSost = 0
        if reading[12] == 1:
            door = "Открыта"
            DverSost = 1
        localtime = time.asctime( time.localtime(time.time()) )
        if reading[15] == 2:
            Sch = "Правый"
        else:
            Sch = "Левый"
        Volt = round((reading[17]*256 + reading[16])*0.0151,2)
        DbmLoc = twos_comp(reading[6],8);
        DbmRet = twos_comp(reading[RXTXLENGTH - 2],8);
        DbmTel = twos_comp(reading[RXTXLENGTH - 3],8);
        if DverSost == 0 and DverSost_1 == 1:
            door = "Отк->Закр"
        if DverSost == 1 and DverSost_1 == 0:
            door = "Закр->Откр"
        if reading[18] == 1:
            Zar = " Заряд"
        else:
            Zar = " Разряд"
        DverSost_1 = DverSost
        Time = str(localtime)
        Tlen = len(Time)
        Tonly = Time[10:19]
        Mesto = str(strings[Str][0])
        XCurr = int(strings[Str][1])
        Seconds = int(Tonly.split(':')[2])
        if Seconds_1 != Seconds:
            Speed = float((XCurr - self.XCurr_1)/(Seconds - self.Seconds_1))
        else:
            Speed = 0.0
        if Speed == 0.0:
            StopCtr = StopCtr + 1
        else:
            StopCtr = 0
        if (StopCtr > 3):
            Speed = "Стоп"
        XCurr_1 = XCurr            
        Seconds_1 = Seconds
        Temperatura = str(temper)
        Schitivatel = str(Sch)
        Voltage     = str(Volt)
        LocDB       = str(DbmLoc)
        RetDB       = str(DbmRet)
        TelDB       = str(DbmTel)
        Vagon       = str(strings[Str][2])
        Skorost     = str(Speed)
        ResArr = [Tonly, Vagon, Mesto, XCurr, Skorost, door, Schitivatel, Temperatura, Voltage, Zar, LocDB, RetDB, TelDB]
        self.out_queue_main.put(ResArr)
        self.out_queue_server.put(ResArr)
            
    
class MainCycle(Thread):
    def __init__(self, out_queue_main):
        Thread.__init__(self)
        self.out_queue_main = out_queue_main
        self.File = open('dataLog.csv','a+')
        self.flush = 0
    def __del__(self):
        self.File.close()
    def run(self):
        while True:
            inputArr = []
            inputArr = self.out_queue_main.get()
            while self.out_queue_main.qsize():
                self.out_queue_main.get()
            Tonly, Vagon, Mesto, XCurr, Skorost, door, Schitivatel, Temperatura, Voltage, Zar, LocDB, RetDB, TelDB = inputArr
            os.system('cls')
            Str1 = "  Время      Вагон     Место"
            print (Str1)
            Str2 = " События       №        №"
            print (Str2)
            Str3 = Tonly + "      " + Vagon + "        " + Mesto 
            print (Str3)
            print ('\n')
            Str1 = "  Скорость    Дверка   Температура"
            print (Str1)
            Str2 = "   км/ч      Состояние     °C"
            print (Str2)
            Str3 = "   " + Skorost + "       " + door + "     " + Temperatura
            print (Str3)
            print ("Акк:" + Zar + " " + Voltage)
            fstr = '"'
            for Emt in inputArr:
                fstr = fstr + "\",\"" + Emt 
            fstr = fstr + '"' + '\n'
            if Vagon == 3:
                pass
            else:
                self.File.write(fstr)
            if self.fflush >= 10:
                self.File.flush()
                self.fflush = 0
            os.system('cls')
            self.fflush = self.fflush + 1
            self.out_queue_main.task_done()
        
if __name__ == '__main__':
    out_queue_main = Queue()
    out_queue_server = Queue()
    os.system('cls')
    server = ThreadedTCPServer(("", 8008), ThreadedTCPHandler, queue=out_queue_server)
    ip, port = server.server_address
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    
    t = MainCycle(out_queue_main)
    t.daemon = True
    t.start()
    t.join(20)  
    
