# -*- coding: utf-8 -*-
import serial
import numpy as np
import os
import time
import threading 
from multiprocessing import Queue
from threading import Thread
import socket
import sys
import socketserver
from flask import Flask, request, render_template
from io import StringIO
import csv

app = Flask(__name__)
app.debug = False
global inputArr
inputArr = []

global inputArrScreen
inputArrScreen = []

@app.route("/", methods=['GET', 'POST'])
def index():
    if request.method == "POST":
        global inputArr
        if out_queue_server.qsize() != 0:        
            inputArr = out_queue_server.get()
        while out_queue_server.qsize() != 0:
            out_queue_server.get()
        data = request.form["data"]
        line = StringIO()
        writer = csv.writer(line, quoting=csv.QUOTE_ALL)
        writer.writerow(inputArr)
        csvcontent = line.getvalue()
        #print (csvcontent)
        return csvcontent
    return render_template("index.html")


def twos_comp(val, bits):
    """compute the 2's complement of int value val"""
    if (val & (1 << (bits - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
        val = val - (1 << bits)        # compute negative value
    return val

strings = {
"0x0 0x0 0x0 0x0":["Start",0,0],
"0x0 0x0 0x0 0x1":["Ping",0,0],
"0x0 0x0 0x0 0x2":["test",0,0],
"0x1a 0xa5 0xbd 0x0":["44",1,3],
"0xf0 0x6c 0xbe 0x0":["42",1,3],
"0x1d 0xa5 0xbd 0x0":["40",2,3],
"0x78 0x4f 0xbe 0x0":["38",2,3],
"0x7a 0x4f 0xbe 0x0":["36",3,3],
"0x8b 0x6e 0xbe 0x0":["34",3,3],
"0x1c 0xa5 0xbd 0x0":["32",4,3],
"0xf4 0x6c 0xbe 0x0":["30",4,3],
"0x1b 0xa5 0xbd 0x0":["28",5,3],
"0x66 0x2c 0xbe 0x0":["26",5,3],
"0x1e 0xa5 0xbd 0x0":["24",6,3],
"0xee 0x6c 0xbe 0x0":["20",6,3],
"0x13 0x3d 0xbe 0x0":["22",7,3],
"0x88 0x6e 0xbe 0x0":["14",7,3],
"0xe1 0x2d 0xbe 0x0":["18",7,3],
"0xf1 0x6c 0xbe 0x0":["16",8,3],
"0x1f 0xa5 0xbd 0x0":["12",8,3],
"0x20 0xa5 0xbd 0x0":["10",9,3],
"0xef 0x6c 0xbe 0x0":["8",9,3],
"0x77 0x4f 0xbe 0x0":["6",10,3],
"0x12 0x3d 0xbe 0x0":["2",10,3],
"0xce 0xa7 0xbd 0x0":["4",11,3],
"0x7e 0x95 0xbd 0x0":["58",11,4],
"0x8c 0x6e 0xbe 0x0":["62",12,4],
"0x79 0x4f 0xbe 0x0":["54",12,4],
"0xf3 0x6c 0xbe 0x0":["56",13,4],
"0x77 0x95 0xbd 0x0":["1Л",0,1],
"0xbc 0x8f 0xbd 0x0":["1П",0,1],
"0x78 0x95 0xbd 0x0":["2Л",0,2],
"0x7a 0x18 0x87 0x0":["1П",0,1],
"0x10 0x3d 0xbe 0x0":["3Л",0,3],
"0x76 0x95 0xbd 0x0":["3П",0,3],
"0x4a 0x8b 0x86 0x0":["2П",0,2],
"0x72 0xb1 0x8b 0x0":["4П",0,4],
"0x87 0x6e 0xbe 0x0":["5П",0,5],
"0x8 0x9 0xa 0xb":["z",0,0]
}


class SerialIO(Thread):
    DATALENGTH = (4+1+2+1+2+1+1+1+1)
    def __init__(self, out_queue_main, out_queue_server):
        Thread.__init__(self)
        self.out_queue_main = out_queue_main
        self.out_queue_server = out_queue_server
        self.ser = serial.Serial('COM3',9600) #timeout = 0.2
        self.DverSost_1 = 0
        self.XCurr_1 = 0
        self.Seconds_1 = 0
        self.StopCtr = 0
    def __del__(self):
        self.ser.close()
    def run(self):
        while True:
            DverSost = 0
            XCurr = 0
            RXTXLENGTH = (SerialIO.DATALENGTH + 9)
            reading = self.ser.readline(RXTXLENGTH)
            while self.ser.inWaiting():
                self.ser.read()
            if len(reading) < RXTXLENGTH:
                continue
            StrA = (' '.join([hex(i) for i in reading]))
            print (str(len(reading)) + " " + StrA)
            #print (Str)
            Str = ' '.join([hex(reading[i]) for i in range(8,12)])
            try:
                strings[Str]
            except  KeyError:
                print ("Другая карта!")
                continue
            temper = (reading[14]*256 + reading[13])/16.0
            door = "Закрыта"
            DverSost = 0
            if reading[12] == 1:
                door = "Открыта"
                DverSost = 1
            localtime = time.asctime( time.localtime(time.time()) )
            if reading[15] == 2:
                Sch = "Правый"
            else:
                Sch = "Левый"
            Volt = round((reading[17]*256 + reading[16])*0.0151,2)
            DbmLoc = twos_comp(reading[6],8);
            if len(reading) <= (RXTXLENGTH - 2):
                continue
            DbmRet = twos_comp(reading[RXTXLENGTH - 2],8);
            DbmTel = twos_comp(reading[RXTXLENGTH - 3],8);
            if DverSost == 0 and self.DverSost_1 == 1:
                door = "Отк->Закр"
            if DverSost == 1 and self.DverSost_1 == 0:
                door = "Закр->Откр"
            if reading[18] == 1:
                Zar = " Заряд"
            else:
                Zar = " Разряд"
            self.DverSost_1 = DverSost
            Time = str(localtime)
            Tlen = len(Time)
            Tonly = Time[11:19]
            Mesto = str(strings[Str][0])
            XCurr = int(strings[Str][1])
            Seconds = int(Tonly.split(':')[2])
            if self.Seconds_1 != Seconds:
                Speed = float((XCurr - self.XCurr_1)/(Seconds - self.Seconds_1))
            else:
                Speed = 0.0
            if Speed == 0.0:
                self.StopCtr = self.StopCtr + 1
            else:
                self.StopCtr = 0
            if (self.StopCtr > 3):
                Speed = "Стоп"
            self.XCurr_1 = XCurr            
            self.Seconds_1 = Seconds
            Temperatura = str(temper)
            Schitivatel = str(Sch)
            Voltage     = str(Volt)
            LocDB       = str(DbmLoc)
            RetDB       = str(DbmRet)
            TelDB       = str(DbmTel)
            Vagon       = str(strings[Str][2])
            Skorost     = str(Speed)
            ResArr = [Tonly, Vagon, Mesto, XCurr, Skorost, door, Schitivatel, Temperatura, Voltage, Zar, LocDB, RetDB, TelDB]
            self.out_queue_main.put(ResArr)
            self.out_queue_server.put(ResArr)
            
    
class MainCycle(Thread):
    def __init__(self, out_queue_main):
        Thread.__init__(self)
        self.out_queue_main = out_queue_main
        self.File = open('dataLog.csv','a+')
        self.fflush = 0
    def __del__(self):
        self.File.close()
    def run(self):
        while True:
            global inputArrScreen
            if self.out_queue_main.qsize() == 0:
                continue
            inputArrScreen = self.out_queue_main.get()
            while self.out_queue_main.qsize():
                self.out_queue_main.get()
            Tonly, Vagon, Mesto, XCurr, Skorost, door, Schitivatel, Temperatura, Voltage, Zar, LocDB, RetDB, TelDB = inputArrScreen
            os.system('cls')
            Str1 = "  Время      Вагон     Место"
            print (Str1)
            Str2 = " События       №        №"
            print (Str2)
            Str3 = Tonly + "      " + Vagon + "        " + Mesto 
            print (Str3)
            print ('\n')
            Str1 = "  Скорость    Дверка   Температура"
            print (Str1)
            Str2 = "   км/ч      Состояние     °C"
            print (Str2)
            Str3 = "   " + Skorost + "       " + door + "     " + Temperatura
            print (Str3)
            print ("Акк:" + Zar + " " + Voltage + " Связь Лок: " + LocDB)
            print (" Связь Ваг: " + RetDB + " Связь Тел: " + TelDB)
            fstr = '"'
            for Emt in inputArr:
                fstr = fstr + "\",\"" + str(Emt)
            fstr = fstr + '"' + '\n'
            if Vagon == 3:
                pass
            else:
                self.File.write(fstr)
            if self.fflush >= 10:
                self.File.flush()
                self.fflush = 0
            self.fflush = self.fflush + 1

if __name__ == '__main__':
    
    out_queue_main = Queue()
    out_queue_server = Queue()
    
    os.system('cls')
    t = SerialIO(out_queue_main, out_queue_server)
    t.daemon = True
    t.start()
    #t.join(20)
    t = MainCycle(out_queue_main)
    t.daemon = True
    t.start()
    #t.join(20)
    app.run(host='192.168.1.46', port=8080, threaded=True)

